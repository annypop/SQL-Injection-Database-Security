config. php - configure database
login. php - allows user to login
register . php - allows user to login
welcome. php - if user was able to login redirect him to welcome page
logout. php - allows user to logout